/*Author: Rainer Hegger Last modified: May 26, 2000*/

#define RESCALE_DATA_ZERO_INTERVAL 11
#define CHECK_ALLOC_NOT_ENOUGH_MEMORY 12
