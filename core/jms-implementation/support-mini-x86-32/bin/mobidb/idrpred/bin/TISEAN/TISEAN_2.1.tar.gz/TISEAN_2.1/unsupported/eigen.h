void esort(double *, double **, long, long);
double pythag(double, double);
void eig1(double **, long, double *, double *);
void eig2(double *, double *, long, double **);
void eigen(double **, long, long);
