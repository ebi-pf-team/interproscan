void dft(double *, long, double *, double *);
void idft(double *, long, double *, double *);
long strip_primes(long);
